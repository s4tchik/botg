from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, CallbackContext, filters, ConversationHandler
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
import openai
import requests
import os
from dotenv import load_dotenv
import asyncio

# Загрузка переменных окружения
load_dotenv()

# Токены и ключи из .env
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")

# Установка OpenAI API
openai.api_key = OPENAI_API_KEY

# Логирование
import logging
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

# Состояния
START, WEATHER, CHATGPT, MEME, REMINDER, GITHUB = range(6)

# Команда /start
async def start(update: Update, context: CallbackContext) -> int:
    keyboard = [
        [InlineKeyboardButton("ChatGPT", callback_data='chatgpt')],
        [InlineKeyboardButton("Погода", callback_data='weather')],
        [InlineKeyboardButton("Мемы", callback_data='meme')],
        [InlineKeyboardButton("Напоминания", callback_data='reminder')],
        [InlineKeyboardButton("Переводчик", callback_data='translator')],
        [InlineKeyboardButton("Игры", callback_data='quiz')],
        [InlineKeyboardButton("GitHub", callback_data='github')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Выберите функцию:", reply_markup=reply_markup)
    return START

# Обработчик кнопок
async def button_handler(update: Update, context: CallbackContext) -> int:
    query = update.callback_query
    await query.answer()

    if query.data == 'chatgpt':
        await query.edit_message_text("Введите сообщение для ChatGPT:")
        return CHATGPT
    elif query.data == 'weather':
        await query.edit_message_text("Введите название города для прогноза погоды:")
        return WEATHER
    elif query.data == 'meme':
        await query.edit_message_text("Введите текст для мема в формате: Вверху | Внизу")
        return MEME
    elif query.data == 'reminder':
        await query.edit_message_text("Введите напоминание в формате: Время Текст")
        return REMINDER
    elif query.data == 'github':
        await query.edit_message_text("Введите имя пользователя или репозитория GitHub.")
        return GITHUB

# Обработчики сообщений
async def chatgpt_handler(update: Update, context: CallbackContext) -> int:
    user_message = update.message.text
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=user_message,
        max_tokens=150
    )
    await update.message.reply_text(response.choices[0].text.strip())
    return START

async def weather_handler(update: Update, context: CallbackContext) -> int:
    city = update.message.text
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={OPENWEATHER_API_KEY}&units=metric&lang=ru"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        weather = data["weather"][0]["description"]
        temp = data["main"]["temp"]
        await update.message.reply_text(f"Погода в {city}: {weather}, температура: {temp}°C.")
    else:
        await update.message.reply_text("Город не найден. Проверьте название.")
    return START

async def meme_handler(update: Update, context: CallbackContext) -> int:
    text = update.message.text.split('|')
    if len(text) != 2:
        await update.message.reply_text("Введите текст в формате: Вверху | Внизу")
        return MEME

    # Создание изображения мема
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new('RGB', (500, 500), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype("arial.ttf", 30)
    draw.text((10, 10), text[0], fill="black", font=font)
    draw.text((10, 450), text[1], fill="black", font=font)
    img_path = "meme.png"
    img.save(img_path)
    await context.bot.send_photo(chat_id=update.message.chat_id, photo=open(img_path, "rb"))
    os.remove(img_path)
    return START

async def reminder_handler(update: Update, context: CallbackContext) -> int:
    msg = update.message.text.split(" ", 1)
    if len(msg) != 2:
        await update.message.reply_text("Введите напоминание в формате: Время Текст")
        return REMINDER

    time, text = msg
    if time not in reminders:
        reminders[time] = []
    reminders[time].append((update.message.chat_id, text))
    await update.message.reply_text(f"Напоминание установлено на {time}.")
    return START

async def github_handler(update: Update, context: CallbackContext) -> int:
    query = update.message.text.strip()
    url = f"https://api.github.com/users/{query}"
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        reply = (f"Пользователь: {data['login']}\n"
                 f"Имя: {data.get('name', 'Нет данных')}\n"
                 f"Публичные репозитории: {data['public_repos']}\n"
                 f"Подписчики: {data['followers']}\n"
                 f"Ссылка: {data['html_url']}")
    else:
        reply = "Пользователь не найден."

    await update.message.reply_text(reply)
    return START

# Основной блок
def main():
    application = Application.builder().token(TELEGRAM_TOKEN).build()

    # Добавление обработчиков
    conversation_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            START: [CallbackQueryHandler(button_handler)],
            WEATHER: [MessageHandler(filters.Text(), weather_handler)],
            CHATGPT: [MessageHandler(filters.Text(), chatgpt_handler)],
            MEME: [MessageHandler(filters.Text(), meme_handler)],
            REMINDER: [MessageHandler(filters.Text(), reminder_handler)],
            GITHUB: [MessageHandler(filters.Text(), github_handler)],
        },
        fallbacks=[],
    )
    
    application.add_handler(conversation_handler)

    # Запуск бота
    application.run_polling()

if __name__ == "__main__":
    main()
