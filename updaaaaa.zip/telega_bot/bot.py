from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, CallbackContext, filters, ConversationHandler
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
import openai
import requests
import os
from dotenv import load_dotenv
import logging
import datetime

openai.api_key = 'pk-**********************************************'
openai.api_base = 'https://api.pawan.krd/v1'

# Загрузка переменных окружения
load_dotenv()

# Токены и ключи из .env
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")

# Установка OpenAI API
openai.api_key = OPENAI_API_KEY

# Настройки прокси для OpenAI
proxies = {
    "http": os.getenv("PROXY_HTTP"),
    "https": os.getenv("PROXY_HTTPS"),
}

# Логирование
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

# Состояния
START, WEATHER, CHATGPT, MEME, REMINDER, GITHUB = range(6)

# Проверка подписки на канал
async def check_subscription(update: Update) -> bool:
    user_id = update.message.chat_id
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/getChatMember?chat_id={CHANNEL_ID}&user_id={user_id}"
    response = requests.get(url)
    data = response.json()

    if data.get("ok") and data["result"]["status"] in ["member", "administrator", "creator"]:
        return True
    return False

# Команда /start с проверкой подписки
async def start(update: Update, context: CallbackContext) -> int:
    if not await check_subscription(update):
        await update.message.reply_text(
            f"Вы не подписаны на канал {CHANNEL_ID}. Подпишитесь и нажмите /start."
        )
        return ConversationHandler.END

    keyboard = [
        [InlineKeyboardButton("ChatGPT", callback_data='chatgpt')],
        [InlineKeyboardButton("Погода", callback_data='weather')],
        [InlineKeyboardButton("Мемы", callback_data='meme')],
        [InlineKeyboardButton("Напоминания", callback_data='reminder')],
        [InlineKeyboardButton("GitHub", callback_data='github')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Выберите функцию:", reply_markup=reply_markup)
    return START

# Обработчик кнопок
async def button_handler(update: Update, context: CallbackContext) -> int:
    query = update.callback_query
    await query.answer()

    if query.data == 'chatgpt':
        await query.edit_message_text("Введите сообщение для ChatGPT:")
        return CHATGPT
    elif query.data == 'weather':
        await query.edit_message_text("Введите название города для прогноза погоды:")
        return WEATHER
    elif query.data == 'meme':
        await query.edit_message_text("Введите текст для мема в формате: Вверху | Внизу")
        return MEME
    elif query.data == 'reminder':
        await query.edit_message_text("Введите напоминание в формате: Время Текст")
        return REMINDER
    elif query.data == 'github':
        await query.edit_message_text("Введите имя пользователя или репозитория GitHub.")
        return GITHUB

# Обработчик кнопки назад
async def back_button(update: Update, context: CallbackContext) -> int:
    query = update.callback_query
    await query.answer()
    keyboard = [
        [InlineKeyboardButton("ChatGPT", callback_data='chatgpt')],
        [InlineKeyboardButton("Погода", callback_data='weather')],
        [InlineKeyboardButton("Мемы", callback_data='meme')],
        [InlineKeyboardButton("Напоминания", callback_data='reminder')],
        [InlineKeyboardButton("GitHub", callback_data='github')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text("Выберите функцию:", reply_markup=reply_markup)
    return START

# Обработчик для ChatGPT
async def chatgpt_handler(update: Update, context: CallbackContext) -> int:
    user_message = update.message.text
    try:
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=user_message,
            max_tokens=150,
            proxies=proxies  # Используем прокси
        )
        await update.message.reply_text(response.choices[0].text.strip())
    except Exception as e:
        logger.error(f"Ошибка в ChatGPT: {e}")
        await update.message.reply_text("Не удалось выполнить запрос к ChatGPT. Попробуйте позже.")
    return START

# Обработчик для погоды
async def weather_handler(update: Update, context: CallbackContext) -> int:
    city = update.message.text
    try:
        # Запрос к API OpenWeather для получения погоды
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={OPENWEATHER_API_KEY}&units=metric&lang=ru"
        response = requests.get(url)
        data = response.json()

        if data.get("cod") != 200:
            await update.message.reply_text("Город не найден. Попробуйте снова.")
            return WEATHER
        
        # Извлечение нужной информации из ответа
        weather_description = data["weather"][0]["description"]
        temperature = data["main"]["temp"]
        humidity = data["main"]["humidity"]
        wind_speed = data["wind"]["speed"]

        # Формирование сообщения
        weather_info = (f"Погода в {city}:\n"
                        f"Описание: {weather_description}\n"
                        f"Температура: {temperature}°C\n"
                        f"Влажность: {humidity}%\n"
                        f"Скорость ветра: {wind_speed} м/с")

        await update.message.reply_text(weather_info)
    except Exception as e:
        logger.error(f"Ошибка при получении погоды: {e}")
        await update.message.reply_text("Не удалось получить погоду. Попробуйте позже.")
    
    keyboard = [
        [InlineKeyboardButton("Назад", callback_data='back')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Вы можете вернуться назад в меню:", reply_markup=reply_markup)
    
    return START

# Обработчик для мемов
async def meme_handler(update: Update, context: CallbackContext) -> int:
    text = update.message.text
    if "|" not in text:
        await update.message.reply_text("Введите текст в формате: Вверху | Внизу")
        return MEME
    
    top_text, bottom_text = text.split("|", 1)
    
    # Здесь можно добавить логику для генерации мема, например, используя сторонние API или изображения
    # Для примера просто отправим текст
    await update.message.reply_text(f"Мем:\nВверху: {top_text.strip()}\nВнизу: {bottom_text.strip()}")
    
    keyboard = [
        [InlineKeyboardButton("Назад", callback_data='back')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Вы можете вернуться назад в меню:", reply_markup=reply_markup)
    
    return START

# Обработчик для напоминаний
async def reminder_handler(update: Update, context: CallbackContext) -> int:
    text = update.message.text
    try:
        # Преобразование текста в формат "Время Текст"
        time_str, reminder_text = text.split(" ", 1)
        reminder_time = datetime.datetime.strptime(time_str, "%H:%M").time()

        # Для примера просто отправим напоминание с временем
        await update.message.reply_text(f"Напоминание установлено на {reminder_time.strftime('%H:%M')} с текстом: {reminder_text}")
        
        keyboard = [
            [InlineKeyboardButton("Назад", callback_data='back')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text("Вы можете вернуться назад в меню:", reply_markup=reply_markup)
        
        return START
    except ValueError:
        await update.message.reply_text("Неверный формат. Пожалуйста, введите в формате: Время Текст (например: 15:30 Покупка хлеба)")
        return REMINDER

# Обработчик для GitHub
async def github_handler(update: Update, context: CallbackContext) -> int:
    github_user = update.message.text.strip()
    try:
        url = f"https://api.github.com/users/{github_user}/repos"
        response = requests.get(url)
        data = response.json()

        if response.status_code != 200:
            await update.message.reply_text("Не удалось найти репозитории для данного пользователя.")
            return GITHUB

        # Формирование ответа
        repos = "\n".join([repo["name"] for repo in data])
        await update.message.reply_text(f"Репозитории пользователя {github_user}:\n{repos}")

    except Exception as e:
        logger.error(f"Ошибка при получении данных с GitHub: {e}")
        await update.message.reply_text("Не удалось получить данные с GitHub. Попробуйте позже.")

    keyboard = [
        [InlineKeyboardButton("Назад", callback_data='back')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Вы можете вернуться назад в меню:", reply_markup=reply_markup)

    return START

# Основная функция для запуска бота
def main():
    application = Application.builder().token(TELEGRAM_TOKEN).build()

    conversation_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            START: [CallbackQueryHandler(button_handler), CallbackQueryHandler(back_button, pattern='^back$')],
            CHATGPT: [MessageHandler(filters.TEXT & ~filters.COMMAND, chatgpt_handler)],
            WEATHER: [MessageHandler(filters.TEXT & ~filters.COMMAND, weather_handler)],
            MEME: [MessageHandler(filters.TEXT & ~filters.COMMAND, meme_handler)],
            REMINDER: [MessageHandler(filters.TEXT & ~filters.COMMAND, reminder_handler)],
            GITHUB: [MessageHandler(filters.TEXT & ~filters.COMMAND, github_handler)],
        },
        fallbacks=[CommandHandler("start", start)],
    )

    application.add_handler(conversation_handler)
    application.run_polling()

if __name__ == "__main__":
    main()
