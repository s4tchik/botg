import logging
import os
import requests
import openai
from PIL import Image, ImageDraw, ImageFont
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, CallbackContext, filters
import schedule
import time
from threading import Thread
from dotenv import load_dotenv
import asyncio  # Импорт asyncio для правильного запуска корутин

# Загрузка переменных окружения
load_dotenv()

# Токены и ключи из .env
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")

# Проверка на наличие токенов
if not all([TELEGRAM_TOKEN, OPENAI_API_KEY, OPENWEATHER_API_KEY, GITHUB_TOKEN]):
    raise ValueError("One or more environment variables are missing!")

# Установка OpenAI API
openai.api_key = OPENAI_API_KEY

# GitHub API URL
GITHUB_API_URL = "https://api.github.com"

# Логирование
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

# Напоминания
reminders = {}

# Команда /start
async def start(update: Update, context: CallbackContext) -> None:
    keyboard = [
        [InlineKeyboardButton("ChatGPT", callback_data='chatgpt')],
        [InlineKeyboardButton("Погода", callback_data='weather')],
        [InlineKeyboardButton("Мемы", callback_data='meme')],
        [InlineKeyboardButton("Напоминания", callback_data='reminder')],
        [InlineKeyboardButton("Переводчик", callback_data='translator')],
        [InlineKeyboardButton("Игры", callback_data='quiz')],
        [InlineKeyboardButton("GitHub", callback_data='github')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Выберите функцию:", reply_markup=reply_markup)

# Обработчик кнопок
async def button_handler(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    await query.answer()
    if query.data == 'chatgpt':
        await query.edit_message_text("Введите сообщение для ChatGPT:")
    elif query.data == 'weather':
        await query.edit_message_text("Введите название города для прогноза погоды:")
    elif query.data == 'meme':
        await query.edit_message_text("Введите текст для мема в формате: Вверху | Внизу")
    elif query.data == 'reminder':
        await query.edit_message_text("Введите напоминание в формате: Время Текст (например, 14:00 Позвонить).")
    elif query.data == 'translator':
        await query.edit_message_text("Введите текст для перевода.")
    elif query.data == 'quiz':
        await query.edit_message_text("Введите /quiz для запуска игры.")
    elif query.data == 'github':
        await query.edit_message_text("Введите имя пользователя или репозитория GitHub (например: 'octocat' или 'octocat/Hello-World').")

# ChatGPT функция
async def chatgpt_handler(update: Update, context: CallbackContext) -> None:
    user_message = update.message.text
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=user_message,
        max_tokens=150
    )
    await update.message.reply_text(response.choices[0].text.strip())

# Погода
async def weather_handler(update: Update, context: CallbackContext) -> None:
    city = update.message.text
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={OPENWEATHER_API_KEY}&units=metric&lang=ru"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        weather = data["weather"][0]["description"]
        temp = data["main"]["temp"]
        await update.message.reply_text(f"Погода в {city}: {weather}, температура: {temp}°C.")
    else:
        await update.message.reply_text("Город не найден. Проверьте название.")

# Мемы
async def meme_handler(update: Update, context: CallbackContext) -> None:
    text = update.message.text.split('|')
    if len(text) != 2:
        await update.message.reply_text("Введите текст в формате: Вверху | Внизу")
        return

    img = Image.new('RGB', (500, 500), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype("arial.ttf", 30)
    draw.text((10, 10), text[0], fill="black", font=font)
    draw.text((10, 450), text[1], fill="black", font=font)
    img_path = "meme.png"
    img.save(img_path)
    await context.bot.send_photo(chat_id=update.message.chat_id, photo=open(img_path, "rb"))
    os.remove(img_path)

# Напоминания
async def reminder_handler(update: Update, context: CallbackContext) -> None:
    msg = update.message.text.split(" ", 1)
    if len(msg) != 2:
        await update.message.reply_text("Введите напоминание в формате: Время Текст")
        return

    time, text = msg
    if time not in reminders:
        reminders[time] = []
    reminders[time].append((update.message.chat_id, text))
    await update.message.reply_text(f"Напоминание установлено на {time}.")

async def check_reminders():
    while True:
        now = time.strftime("%H:%M")
        if now in reminders:
            for chat_id, text in reminders[now]:
                await context.bot.send_message(chat_id=chat_id, text=f"Напоминание: {text}")
            del reminders[now]
        time.sleep(60)

# GitHub API
async def github_handler(update: Update, context: CallbackContext) -> None:
    query = update.message.text.strip()
    if "/" in query:  # Репозиторий
        url = f"{GITHUB_API_URL}/repos/{query}"
    else:  # Пользователь
        url = f"{GITHUB_API_URL}/users/{query}"

    headers = {
        "Authorization": f"token {GITHUB_TOKEN}"
    }
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        if "full_name" in data:  # Репозиторий
            reply = (f"Репозиторий: {data['full_name']}\n"
                     f"Описание: {data['description']}\n"
                     f"Звёзды: {data['stargazers_count']}\n"
                     f"Ссылка: {data['html_url']}")
        else:  # Пользователь
            reply = (f"Пользователь: {data['login']}\n"
                     f"Имя: {data.get('name', 'Нет данных')}\n"
                     f"Публичные репозитории: {data['public_repos']}\n"
                     f"Подписчики: {data['followers']}\n"
                     f"Ссылка: {data['html_url']}")
    else:
        reply = "Пользователь или репозиторий не найдены."

    await update.message.reply_text(reply)

# Основной блок
def main():
    application = Application.builder().token(TELEGRAM_TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_handler(MessageHandler(filters.Text() & ~filters.Command(), chatgpt_handler))
    application.add_handler(MessageHandler(filters.Text() & ~filters.Command(), weather_handler))
    application.add_handler(MessageHandler(filters.Text() & ~filters.Command(), meme_handler))
    application.add_handler(MessageHandler(filters.Text() & ~filters.Command(), reminder_handler))
    application.add_handler(MessageHandler(filters.Text() & ~filters.Command(), github_handler))

    # Запуск бота
    application.run_polling()

if __name__ == "__main__":
    asyncio.run(main())  # Используем asyncio.run для корректного запуска корутин
